classdef Custom_MSEnergy_
    %CUSTOM_MSENERGY Allows users to input custom energy functions for the
    %MS Particle
    %   Detailed explanation goes here
    
    properties
    end
    
    methods
    end
    
end

