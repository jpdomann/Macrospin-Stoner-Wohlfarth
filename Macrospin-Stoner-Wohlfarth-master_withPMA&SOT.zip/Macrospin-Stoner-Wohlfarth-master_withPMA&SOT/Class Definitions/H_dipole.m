function [ output_args ] = H_dipole( input_args )
%H_DIPOLE Summary of this function goes here
%   Detailed explanation goes here


end

